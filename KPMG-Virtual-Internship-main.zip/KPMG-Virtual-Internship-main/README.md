# KPMG-Virtual-Internship
This repo contains solutions to the 3 tasks that must be performed during the data analytics virtual internship provided by **KPMG** via **Forage**. 

# Intership Description
I) **TASK 1:** Data Quality Assessment - Assessment of data quality and completeness in preparation for analysis. 

II) **TASK 2:** Data Insights - Targeting high-value customers based on customer demographics and attributes. 

III) **TASK 3:** Data Insights and Presentation -  Using visualisations to present insights.
